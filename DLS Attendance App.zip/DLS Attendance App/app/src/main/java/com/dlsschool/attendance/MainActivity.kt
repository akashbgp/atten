package com.dlsschool.attendance

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewFeature
import androidx.webkit.WebViewRenderProcess
import androidx.webkit.WebViewRenderProcessClient
import com.dlsschool.attendance.databinding.ActivityMainBinding
import com.dlsschool.attendance.utils.Constants
import com.dlsschool.attendance.utils.PreferenceManager

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var webView: WebView
    private val prefs by lazy { PreferenceManager(this) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWebView()
        startAttendanceProcess()
    }

    private fun setupWebView() {
        webView = binding.webView
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setGeolocationEnabled(false)
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            allowFileAccess = false
            allowContentAccess = false
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.RENDER_PROCESS_GONE_SAFETY_NET)) {
            webView.setRendererPriorityPolicy(
                WebView.RENDERER_PRIORITY_BOUND,
                true
            )
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                when {
                    url == Constants.LOGIN_URL -> performLogin()
                    url?.contains("dashboard") == true -> navigateToQRAttendance()
                    url?.contains("qr-attendance") == true -> activateScanner()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
        }
    }

    private fun startAttendanceProcess() {
        webView.loadUrl(Constants.LOGIN_URL)
    }

    private fun performLogin() {
        val username = prefs.getUsername()
        val password = prefs.getPassword()

        val loginScript = """
            javascript:(function() {
                document.getElementById('loginform-username').value = '$username';
                document.getElementById('loginform-password').value = '$password';
                document.querySelector('button[type="submit"]').click();
            })()
        """.trimIndent()

        webView.evaluateJavascript(loginScript, null)
    }

    private fun navigateToQRAttendance() {
        webView.evaluateJavascript(
            "javascript:(function() { document.querySelector('a[href*=\"qr-attendance\"]').click(); })()",
            null
        )
    }

    private fun activateScanner() {
        webView.evaluateJavascript(
            "javascript:(function() { document.querySelector('button:contains(\"Attendance\")').click(); })()",
            null
        )
    }

    override fun onBackPressed() {
        // Disable back button
    }
}
