package com.dlsschool.attendance.workers

import android.content.Context
import android.content.Intent
import androidx.work.*
import com.dlsschool.attendance.DLSAttendanceApp
import com.dlsschool.attendance.MainActivity
import com.dlsschool.attendance.utils.Constants
import java.util.Calendar
import java.util.concurrent.TimeUnit

class AttendanceWorker(
    context: Context,
    params: WorkerParameters
) : Worker(context, params) {

    override fun doWork(): Result {
        val now = Calendar.getInstance()
        
        when (inputData.getString(KEY_ACTION)) {
            ACTION_START -> handleStart(now)
            ACTION_STOP -> handleStop(now)
        }

        return Result.success()
    }

    private fun handleStart(now: Calendar) {
        if (now.get(Calendar.HOUR_OF_DAY) in 6..8) {
            val intent = Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            applicationContext.startActivity(intent)
        }
    }

    private fun handleStop(now: Calendar) {
        if (now.get(Calendar.HOUR_OF_DAY) >= 9) {
            // Lock device
            val app = DLSAttendanceApp.instance
            if (app.devicePolicyManager.isAdminActive(app.deviceAdmin)) {
                app.devicePolicyManager.lockNow()
            }
        }
    }

    companion object {
        private const val KEY_ACTION = "action"
        private const val ACTION_START = "start"
        private const val ACTION_STOP = "stop"

        fun scheduleDaily(context: Context) {
            val workManager = WorkManager.getInstance(context)
            
            // Schedule start at 6 AM
            val startCalendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 6)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                if (before(Calendar.getInstance())) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }

            val startDelay = startCalendar.timeInMillis - System.currentTimeMillis()
            val startRequest = OneTimeWorkRequestBuilder<AttendanceWorker>()
                .setInitialDelay(startDelay, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf(KEY_ACTION to ACTION_START))
                .build()

            // Schedule stop at 9 AM
            val stopCalendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 9)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                if (before(Calendar.getInstance())) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }

            val stopDelay = stopCalendar.timeInMillis - System.currentTimeMillis()
            val stopRequest = OneTimeWorkRequestBuilder<AttendanceWorker>()
                .setInitialDelay(stopDelay, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf(KEY_ACTION to ACTION_STOP))
                .build()

            workManager.beginUniqueWork(
                Constants.WORK_NAME_START,
                ExistingWorkPolicy.REPLACE,
                startRequest
            ).then(stopRequest).enqueue()
        }
    }
}
