package com.dlsschool.attendance.utils

object Constants {
    const val LOGIN_URL = "https://login.dlsschool.in/site/login"
    const val DEFAULT_USERNAME = "attendance@dlsschool.in"
    const val DEFAULT_PASSWORD = "123456"
    const val WORK_NAME_START = "attendance_start"
    const val WORK_NAME_STOP = "attendance_stop"
}
