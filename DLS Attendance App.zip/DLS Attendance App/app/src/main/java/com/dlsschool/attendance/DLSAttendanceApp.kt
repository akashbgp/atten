package com.dlsschool.attendance

import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import androidx.work.Configuration
import androidx.work.WorkManager

class DLSAttendanceApp : Application(), Configuration.Provider {
    
    companion object {
        lateinit var instance: DLSAttendanceApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        initializeWorkManager()
    }

    private fun initializeWorkManager() {
        WorkManager.initialize(
            this,
            Configuration.Builder()
                .setMinimumLoggingLevel(android.util.Log.INFO)
                .build()
        )
    }

    override fun getWorkManagerConfiguration(): Configuration {
        return Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
    }

    val devicePolicyManager: DevicePolicyManager by lazy {
        getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    }

    val deviceAdmin: ComponentName by lazy {
        ComponentName(this, DeviceAdminReceiver::class.java)
    }
}
